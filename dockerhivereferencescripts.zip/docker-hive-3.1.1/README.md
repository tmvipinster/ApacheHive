# Apache Hive 3.1.1 Docker image

[![DockerPulls](https://img.shields.io/docker/pulls/dvoros/hive.svg)](https://registry.hub.docker.com/u/dvoros/hive/)
[![DockerStars](https://img.shields.io/docker/stars/dvoros/hive.svg)](https://registry.hub.docker.com/u/dvoros/hive/)

_Note: For instructions on how to build and use this image refer to the README.md on the master branch_

With Oracle JDK8 and Hadoop 3.1.1 and Tez 0.9.1.
