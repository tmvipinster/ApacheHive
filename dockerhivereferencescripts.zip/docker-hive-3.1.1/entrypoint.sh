#!/bin/bash

# Start Hadoop and Hive services
/etc/docker-startup/hive-bootstrap.sh

# Leave user with a shell
/bin/bash
